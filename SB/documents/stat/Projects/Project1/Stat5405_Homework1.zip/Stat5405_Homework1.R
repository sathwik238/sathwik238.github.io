data(trees)
boxplot(trees$Volume,varwidth=TRUE)

boxplot(trees$Girth,notch = TRUE)

library(ggplot2)
ggplot(data = trees,mapping = aes(y=Volume,x=0)) +
  geom_boxplot(col="black",fill="lightblue",width=0.1) + coord_flip() + theme_light()


library(car)
qqPlot(trees$Volume, main="", ylab="Volume", cex=0.6,pch=19, col="red", 
       col.lines = "orange")


shapiro.test(trees$Volume)

library(nortest) 
pearson.test(trees$Volume) 

scatterplotMatrix(~mtcars$mpg+mtcars$disp+mtcars$hp+mtcars$drat+mtcars$wt+mtcars$qsec, data=mtcars)

data(mtcars)

selected_columns <- mtcars[, c("mpg", "disp", "hp", "drat", "wt", "qsec")]

correlation_matrix <- cor(selected_columns)

diag(correlation_matrix) <- NA

max_correlation <- max(correlation_matrix, na.rm = TRUE)

indices <- which(correlation_matrix == max_correlation, arr.ind = TRUE)

column1 <- rownames(correlation_matrix)[indices[1, 1]]
column2 <- colnames(correlation_matrix)[indices[1, 2]]

cat("Pair with maximum correlation:", column1, "and", column2, "with correlation =", max_correlation, "\n")

library(dplyr)

mumbai_data <- read.csv('Temperature_And_Precipitation_Cities_IN/Mumbai_1990_2022_Santacruz.csv')


chennai_data <- read.csv('Temperature_And_Precipitation_Cities_IN/Chennai_1990_2022_Madras.csv')

delhi_data <- read.csv('Temperature_And_Precipitation_Cities_IN/Delhi_NCR_1990_2022_Safdarjung.csv')


banglore_data <- read.csv('Temperature_And_Precipitation_Cities_IN/Bangalore_1990_2022_BangaloreCity.csv')



# Combine the datasets with a grouping variable
combined_data <- bind_rows(
  mutate(mumbai_data, Group = "Mumbai"),
  mutate(chennai_data, Group = "Chennai"),
  mutate(delhi_data, Group = "Delhi"),
  mutate(banglore_data, Group = "Banglore")
)


boxplot(combined_data$tavg ~ combined_data$Group, xlab="City", 
        ylab="Avg Temprature", border = "blue", col="lightblue",notch=TRUE)



